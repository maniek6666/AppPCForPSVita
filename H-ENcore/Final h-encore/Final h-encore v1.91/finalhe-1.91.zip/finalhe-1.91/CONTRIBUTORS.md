* Translations
    * Chinese: [Soar Qin](https://github.com/soarqin)
    * Czech: [spenaat](https://github.com/spenaat)
    * German: [Philipp](https://github.com/pseiler)
    * Italian: [theheroGAC](https://github.com/theheroGAC)
    * Japanese: [Hack-Usagi](https://github.com/Hack-Usagi)
    * Russian: [M2l2koPOWER](https://github.com/M2l2koPOWER)
    * Spanish: [Z3R0](https://github.com/RY0M43CH1Z3N)
    * Turkish: [caghandemir](https://github.com/caghandemir)
