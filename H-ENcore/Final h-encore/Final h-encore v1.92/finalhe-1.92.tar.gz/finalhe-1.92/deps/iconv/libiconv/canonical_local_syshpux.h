  (int)(long)&((struct stringpool_t *)0)->stringpool_str171,
  (int)(long)&((struct stringpool_t *)0)->stringpool_str723,
