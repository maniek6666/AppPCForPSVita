#pragma once

#ifdef __cplusplus
extern "C" {
#endif
int psvimg_create(const char *inputdir, const char *outputdir, const char *key, const char *meta_name, int is_meta);
#ifdef __cplusplus
}
#endif
