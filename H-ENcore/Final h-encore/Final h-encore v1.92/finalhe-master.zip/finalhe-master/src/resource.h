﻿#include <winres.h>
