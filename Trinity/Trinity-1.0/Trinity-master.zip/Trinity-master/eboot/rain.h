#ifndef __RAIN_H__
#define __RAIN_H__

void matrix_rain(const char *string);
int rain_animation(void);

#endif
